#!/usr/bin/env bash
# 手机 QQ 机器人部署 · 环境探测
#
# 运行位置：agent 自己这台机器（需要 adb）。不是推到手机上跑的脚本。
# 用法：
#   ./probe-adb.sh              # 自动选唯一设备
#   ./probe-adb.sh <serial>     # 指定设备
#   ADB=/path/to/adb ./probe-adb.sh
#
# Git Bash / MSYS 下建议先 export MSYS_NO_PATHCONV=1，避免 /data/... 被当路径转换

set -u
ADB="${ADB:-adb}"
ADB_ARG=()
[ $# -ge 1 ] && [ -n "${1:-}" ] && ADB_ARG=(-s "$1")

say() { printf '%s\n' "$*"; }
sh_() { "$ADB" "${ADB_ARG[@]}" shell "$@" 2>/dev/null | tr -d '\r'; }

say "=============================================="
say " 手机 QQ 机器人部署 · 环境探测"
say "=============================================="

# ---------- 1. 连接 ----------
say ""
say "--- [1/6] 设备连接 ---"
DEVS=$("$ADB" devices 2>/dev/null | awk 'NR>1 && $2=="device"{print $1}')
if [ -z "$DEVS" ]; then
  say "  !! 没有已授权的设备。"
  say "     检查：USB 调试是否开启；手机上是否有授权弹窗需要点确认；换网络 adb 时先 adb connect。"
  exit 1
fi
CNT=$(printf '%s\n' "$DEVS" | wc -l | tr -d ' ')
say "  已授权设备数：$CNT"
printf '%s\n' "$DEVS" | sed 's/^/    /'
if [ "$CNT" -gt 1 ] && [ ${#ADB_ARG[@]} -eq 0 ]; then
  say "  !! 多台设备，请把目标 serial 作为参数传入。"
  exit 1
fi

# ---------- 2. 基本信息 ----------
say ""
say "--- [2/6] 设备与系统 ---"
MODEL=$(sh_ 'getprop ro.product.model')
REL=$(sh_ 'getprop ro.build.version.release')
SDK=$(sh_ 'getprop ro.build.version.sdk')
ABI=$(sh_ 'getprop ro.product.cpu.abi')
MACHINE=$(sh_ 'uname -m')
say "  型号        : $MODEL"
say "  Android     : $REL (sdk $SDK)"
say "  主 ABI      : $ABI"
say "  内核架构    : $MACHINE"

case "$ABI" in
  arm64*|aarch64*) PKG_ARCH="arm64" ;;
  armeabi-v7a*)    PKG_ARCH="armhf" ;;
  x86_64*)         PKG_ARCH="amd64" ;;
  x86*)            PKG_ARCH="i386"  ;;
  *)               PKG_ARCH="unknown" ;;
esac
say "  → 选包架构  : $PKG_ARCH  (NapCat/LinuxQQ/rootfs 都要用这个)"

# ---------- 3. root ----------
say ""
say "--- [3/6] root 权限 ---"
IDOUT=$(sh_ 'su -c id')
case "$IDOUT" in
  *uid=0*) say "  root 可用：$IDOUT" ;;
  "")      say "  !! 'su -c id' 无输出。" 
           say "     多半是 root 管理器在等屏幕授权。屏幕不可达时可往 Magisk 数据库预放行："
           say "     magisk --sqlite \"INSERT OR REPLACE INTO policies (uid,policy,until,logging,notification,package_name) VALUES (<uid>,2,0,1,1,'<pkg>')\""
           say "     （policy=2 表示 ALLOW；<uid> 用 dumpsys package <pkg> | grep userId 取）" ;;
  *)       say "  !! su 返回非 root：$IDOUT" ;;
esac

# ---------- 4. 网络 ----------
say ""
say "--- [4/6] 网络 ---"
SSID=$(sh_ 'dumpsys wifi 2>/dev/null | grep -m1 "mWifiInfo SSID"')
say "  WiFi        : ${SSID:-（未取到）}"
IP4=$(sh_ 'ip -o -4 addr show 2>/dev/null | grep -v " lo " | head -2')
[ -n "$IP4" ] && printf '  本机地址    : %s\n' "$(printf '%s' "$IP4" | tr '\n' ' ')"
GW=$(sh_ 'ping -c 2 -W 3 223.5.5.5 2>/dev/null | tail -2 | head -1')
say "  连通性      : ${GW:-（ping 无结果，可能只是禁 ICMP，需用 TCP 再验）}"

# ---------- 5. 容器能力 ----------
say ""
say "--- [5/6] 内核容器能力（决定能不能用 Docker） ---"
if [ "$(sh_ 'test -r /proc/config.gz && echo yes')" = "yes" ]; then
  CFG=$(sh_ 'zcat /proc/config.gz 2>/dev/null | grep -E "^(CONFIG_NAMESPACES|# CONFIG_NAMESPACES|CONFIG_CGROUP_DEVICE|# CONFIG_CGROUP_DEVICE|CONFIG_MEMCG|# CONFIG_MEMCG|CONFIG_VETH|# CONFIG_VETH|CONFIG_BRIDGE|# CONFIG_BRIDGE)"')
  if [ -n "$CFG" ]; then
    printf '%s\n' "$CFG" | sed 's/^/    /'
    case "$CFG" in
      *"# CONFIG_CGROUP_DEVICE is not set"*|*"# CONFIG_NAMESPACES is not set"*)
        say "  → 结论：Docker 不可用（缺关键容器原语）。走非 Docker 路线。" ;;
      *) say "  → 结论：配置看起来齐全，但仍需实测 dockerd 能否启动。" ;;
    esac
  fi
else
  say "    （读不到 /proc/config.gz，用 /proc/cgroups 粗看）"
  sh_ 'cat /proc/cgroups' | sed 's/^/    /'
  NSOK=$(sh_ 'unshare -p -f true 2>&1 && echo PIDNS_OK')
  case "$NSOK" in *PIDNS_OK*) say "  → 能创建 PID namespace；Docker 仍可能因 cgroup 缺失而失败" ;;
                 *) say "  → 不能创建 PID namespace：Docker 必然不可用，走非 Docker 路线" ;; esac
fi

# ---------- 6. 资源 ----------
say ""
say "--- [6/6] 资源 ---"
sh_ 'free -m 2>/dev/null | head -2' | sed 's/^/  /'
sh_ 'df -h /data /sdcard 2>/dev/null | head -4' | sed 's/^/  /'
say "  提示：QQ 客户端 + AstrBot 常驻，建议预留 1GB 以上内存、2GB 以上磁盘。"

say ""
say "=============================================="
say " 探测完成。下一步：按 SKILL.md 阶段 1 准备 Linux 用户空间"
say "=============================================="
