#!/bin/sh
# 容器层服务看门狗模板
#
# 放在容器内（例如 /usr/local/bin/svc-watchdog），由容器的开机脚本（rc.local 之类）启动。
# 作用：每 INTERVAL 秒检查下表里的服务，掉了就按 restart 命令拉起来，带冷却时间防止重启风暴。
#
# 改法：只改下面 SERVICES 表即可。每行四个字段，用 | 分隔：
#   名称|检测类型|检测目标|冷却秒数|重启命令
#   检测类型：proc = 在 /proc/*/cmdline 里找关键字；http = 请求本地端口
#
# 为什么不用 ps|grep 判断进程：很多 Android 环境的 ps 只显示进程名，会误判。

PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH

INTERVAL=${INTERVAL:-30}
LOG=${LOG:-/var/log/svc-watchdog.log}
LOG_MAX_LINES=${LOG_MAX_LINES:-500}

SERVICES="
rsyslogd|proc|rsyslogd|60|/usr/sbin/rsyslogd
frpc|proc|frpc|60|/usr/local/bin/frpc-tunnel start
astrbot|http|6185|120|/usr/local/bin/astrbot-svc start
napcat|proc|opt/QQ/qq|180|/usr/local/bin/napcat-svc start
"

has_proc() {   # $1 = cmdline 关键字
  for p in /proc/[0-9]*; do
    c=$(tr '\0' ' ' < "$p/cmdline" 2>/dev/null)
    case "$c" in *"$1"*) return 0;; esac
  done
  return 1
}

# 冷却：允许动手返回 0，还在冷却期返回 1
cool() {       # $1 = 名称, $2 = 冷却秒
  f="/run/wd-$1.ts"
  now=$(date +%s)
  last=$(cat "$f" 2>/dev/null || echo 0)
  [ $((now - last)) -lt "$2" ] && return 1
  echo "$now" > "$f" 2>/dev/null
  return 0
}

log() {
  echo "$(date '+%F %T') $*" >> "$LOG" 2>/dev/null
  if [ "$(wc -l < "$LOG" 2>/dev/null || echo 0)" -gt "$LOG_MAX_LINES" ]; then
    tail -n $((LOG_MAX_LINES / 2)) "$LOG" > "$LOG.tmp" 2>/dev/null && mv "$LOG.tmp" "$LOG"
  fi
}

log "watchdog started (pid $$, interval ${INTERVAL}s)"

while true; do
  sleep "$INTERVAL"

  printf '%s\n' "$SERVICES" | while IFS='|' read -r name ctype target cd restart; do
    [ -n "${name:-}" ] || continue
    case "$name" in \#*) continue;; esac

    alive=1
    case "$ctype" in
      proc) has_proc "$target" || alive=0 ;;
      http) curl -s -m 6 -o /dev/null "http://127.0.0.1:$target/" 2>/dev/null || alive=0 ;;
      *)    alive=1 ;;
    esac

    if [ "$alive" -eq 0 ]; then
      if cool "$name" "$cd"; then
        $restart >/dev/null 2>&1
        log "restart $name"
      fi
    fi
  done

  # 兜底：DNS 配置丢了会影响一切网络访问
  [ -s /etc/resolv.conf ] || printf 'nameserver 223.5.5.5\nnameserver 8.8.8.8\n' > /etc/resolv.conf 2>/dev/null
done
