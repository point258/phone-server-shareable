---
name: android-napcat-astrbot
description: 在已 root 的 Android 手机上部署 QQ 机器人服务（NapCat + AstrBot），并发布到公网、配置长期保活。当用户提到「手机跑 QQ 机器人」「在手机上装 NapCat / AstrBot / QQ 机器人框架」「把手机做成服务器」「手机 Linux 容器 / Linux Deploy / Termux 部署服务」「内网穿透发 WebUI」，或要用 adb 在 Android 上部署/排查这类服务时使用——即使用户没有同时说出 AstrBot 和 NapCat 两个名字。也适用于排查这类部署的故障：容器起不来、QQ 登录不上、隧道被中转拦截、进程被杀、重启后服务没起来。
---

# 在 root 手机上部署 NapCat + AstrBot

目标：把一台已 root 的 Android 手机变成常驻的 QQ 机器人服务器，公网可访问、崩溃自愈、重启后自动恢复。

本 skill 给的是**最低必要路径**，不限机型与系统版本。带设备特异性的坑放在
`references/troubleshooting.md`，按「现象」查，不要一上来就照搬。

## 先读这一条，能省你几小时

**不要试图在手机上跑 Docker。** 手机内核几乎都不满足 Docker 的前置条件（缺
`CONFIG_NAMESPACES`、`CONFIG_CGROUP_DEVICE`、`CONFIG_MEMCG`、`CONFIG_VETH`/
`CONFIG_BRIDGE` 等），dockerd 会直接报 `Devices cgroup isn't mounted`。这是**内核编译
期的缺失，换发行版、换用户空间都不解决**——包括把手机刷成 GNU/Linux 用户空间
（Halium/Droidian 那类），因为内核没换。

好消息是**这两个服务都不需要 Docker**：

- NapCat 官方提供非 Docker 的 Linux 安装方式（一键脚本 + Xvfb + LinuxQQ 客户端）
- AstrBot 可以用 Python 源码部署

如果用户坚持要 Docker / 1Panel，直接告诉他这条路在手机上行不通，需要的是一台正常
Linux（VPS 或闲置电脑），别在手机内核上耗时间。

## 前提

**硬前提：一台 bootloader 已解锁、且已 root 的 Android 手机。** 这两个顺序不能反——不解锁
bootloader 就写不进 boot 分区，也就 root 不了。

如果手机还没解锁/root，那是**另一个高风险项目**：解锁会**清空全部数据**，部分机型厂商已经关闭
官方解锁渠道（例如华为自 2018 年起不再向用户发放解锁码），刷错会开不了机。**不要在用户没有
明确知情同意的情况下擅自解锁或刷机**，也不要承诺"一定能 root"。遇到这种情况先把风险讲清楚，
或者建议用户换一台已解锁的旧机 / 直接用 VPS。做法与注意事项见
`references/root-and-unlock.md`。

其余前提：

- `su` 可用，adb 连接正常（USB 或网络），能通过 adb 执行 root 命令
- 手机自己能上网（WiFi 或数据）
- 需要一个 **Linux 用户空间**，只要满足两点就够：有包管理器（apt 等）、能跑与本机同架构的原生二进制。

  本文每一步都以 **Linux Deploy 的 chroot** 为例（它自带 busybox 与 CLI，适合无人值守操作）。
  Termux + proot-distro、其它 chroot/LXC 方案理论上同样可行，但**本 skill 未在那些环境验证过**，
  照搬时要注意路径约定与 chroot 行为的差异（例如 proot 下 `chroot` 的假设不成立）。

## 阶段 0 · 环境探测（别跳）

```bash
adb shell 'getprop ro.build.version.release; getprop ro.product.cpu.abi; uname -m; su -c id'
```

判据：

- `su -c id` 必须返回 `uid=0`。如果卡住不返回，通常是 Magisk 在等屏幕上点授权——
  屏幕不可达时，可以直接往 Magisk 数据库写放行记录：
  ```bash
  adb shell "su -c 'magisk --sqlite \"INSERT OR REPLACE INTO policies (uid,policy,until,logging,notification,package_name) VALUES (<app_uid>,2,0,1,1,''<pkg>'')\"'"
  # policy=2 表示 ALLOW；<app_uid> 用 dumpsys package <pkg> | grep userId 取
  ```
- `ro.product.cpu.abi` / `uname -m` 决定后面选 arm64 还是 x86 的包
- 顺手确认内核确实不支持容器，好在用户问起时有据可答：
  ```bash
  adb shell "su -c 'zcat /proc/config.gz 2>/dev/null | grep -E \"CONFIG_NAMESPACES|CONFIG_CGROUP_DEVICE|CONFIG_VETH\" || cat /proc/cgroups'"
  ```

`scripts/probe-adb.sh` 把这一阶段合并成一条命令。

## 阶段 1 · 准备 Linux 用户空间

以 Linux Deploy 为例（用其它方案时，把它替换成"准备一个能跑 apt 的 Linux 环境"）：

1. 安装 App（F-Droid 与其 GitHub Releases 都有分发），**先启动一次**，让它在 `files/` 下解压自带
   资源（busybox、`cli.sh`、`include/`），后面所有 CLI 调用都依赖它。
2. **用 rootfs 压缩包导入，不要用 debootstrap。** 手机上跑 debootstrap 又慢又依赖网络稳定；
   在 PC 上取一份官方 base rootfs 推过去更可靠：
   ```bash
   curl -O https://cdimage.ubuntu.com/ubuntu-base/releases/22.04/release/ubuntu-base-22.04.4-base-arm64.tar.gz
   adb push ubuntu-base-22.04.4-base-arm64.tar.gz /data/local/tmp/
   ```
   然后把它设成配置里的 `SOURCE_PATH`：在 App 的「属性」里改「源地址」，或直接编辑
   `/data/data/<包名>/files/config/<profile>.conf` 里那一行（改完要停止再启动容器、或重启 App
   才生效）。Linux Deploy 检测到源是归档文件时会走 `rootfs_import` 而不是 debootstrap。
3. **容器用「目录」而不是镜像文件**（`TARGET_TYPE=directory`）。镜像文件在 arm64 上容易
   卡在 `mke2fs`（App 的 arm64 资源里往往没带 mke2fs），目录方式不需要 loop 设备。
4. 装完记得把以下定制做掉，**否则后面会出现一堆莫名其妙的失败**：
   - 注释掉容器内 `/etc/pam.d/{su,su-l,login,runuser,runuser-l,sshd}` 里的 `pam_keyinit.so`
     （原因见 troubleshooting：某些设备上会让 `su` 会话内写文件失败）
   - 给容器里的 root 加 sudoers 权限：`root ALL=(ALL:ALL) NOPASSWD:ALL`
     （NapCat 安装脚本用 `sudo` 装依赖，而很多 rootfs 的 root 不在 sudoers 里）
   - apt 源换成国内镜像（`mirrors.tuna.tsinghua.edu.cn` 等），否则后续下载会非常慢
5. 验证：能进容器并执行命令
   ```bash
   adb shell "su -c 'sh /data/local/tmp/<cli>.sh status'"
   adb shell "su -c 'sh /data/local/tmp/<cli>.sh shell \"uname -a\"'"
   ```

**调用容器内命令时自己写一个包装脚本**，别用多层引号（`adb shell "su -c '...'"` 里再套
转义极其容易写坏并让 shell 卡住等输入）。可靠做法始终是：本地写脚本 → `adb push` →
`su -c 'sh /data/local/tmp/x.sh'`。

## 阶段 2 · 安装 NapCat

细节（含参数、QQ 包获取、启动命令）见 `references/napcat.md`。要点：

- 用官方一键脚本的**非 Docker**模式：`bash napcat.sh --docker n --cli n`
- 它需要 Xvfb 和 QQ 客户端（LinuxQQ 官方有 arm64 与 amd64 包）
- 脚本里写死的 QQ 下载链接**经常 404**。先在 PC 上确认当前的包地址，把包装成脚本期望的
  文件名放进同一目录，脚本会优先用本地包
- 启动方式：`xvfb-run -a <安装目录>/opt/QQ/qq --no-sandbox`
  **`--no-sandbox` 必须加**——容器里没有 user namespace，Chromium 沙箱起不来
- 验证：NapCat WebUI（默认 6099）在监听

## 阶段 3 · 安装 AstrBot

细节见 `references/astrbot.md`。要点：

- 源码部署：下载仓库 zip → `pip install -r requirements.txt` → `python3 main.py`
- Python 需 3.10+
- pip 走国内镜像，否则依赖安装可能慢到不可用
- 如果环境从 Android 继承了 `ANDROID_ROOT`/`ANDROID_DATA` 等变量，pip 会误判平台为
  Android 并崩溃（`Cannot find path to android app folder`）。对策：用干净环境跑
  `env -i PATH=... HOME=/root python3 -m pip ...`
- 验证：`curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:6185/` 返回 200

## 阶段 4 · 打通两者

1. 在 NapCat WebUI 里配置 OneBot（WS 服务端），记下端口和 token
2. **让用户用手机 QQ 扫 NapCat WebUI 里的二维码完成登录**——这一步 agent 做不了，
   必须交给用户，而且二维码会不断刷新，所以要引导用户去 WebUI 里扫实时的
3. 在 AstrBot WebUI 里添加 `aiocqhttp` 适配器，填 NapCat 的 OneBot 地址与 token
4. 验证：AstrBot 日志出现 QQ 会话消息（`[default(aiocqhttp)] ...: <消息内容>`）

## 阶段 5 · 发布到公网

见 `references/tunnel-and-tls.md`。要点：

- 用 frp 类穿透服务给 WebUI 开 **TCP** 隧道，指向容器内 WebUI 端口
- **国内中转普遍会拦明文 HTTP**（返回 501/403 合规页）。对策：在容器内做 **TLS 终结**
  （stunnel 或 nginx + 自签证书），隧道指向 TLS 端口，对外用 `https://` 访问
- 交付时必须给用户：公网地址（含协议+端口）、面板账号/密码/token

## 阶段 6 · 保活（"长期可用"的关键）

见 `references/keepalive.md`。要点：

- **容器层看门狗**：每 30s 检查各服务（进程/端口）并按需重启，带冷却防重启风暴
  （`scripts/svc-watchdog.sh` 是可直接改用的模板）
- **手机层看门狗**：以 root 常驻（Magisk 用 `/data/adb/service.d/`，其它 root 方案用等价
  的开机脚本），检查 WiFi、容器挂载、容器内 sshd，顺便重申性能/电源策略
- **不要依赖 App 自己的开机广播**：各家 OEM 的「应用启动管理」默认会拦掉它。跑在 root
  层的守护进程不受应用管理约束，这是可靠的自启途径
- 想熄屏/不插电常驻时，需要持有内核 wake lock（`echo <name> > /sys/power/wake_lock`）
  并关掉系统的 Doze / 后台限制

## 完成判据（全过才算交付）

- [ ] 容器启动正常，能进容器执行命令
- [ ] NapCat WebUI 返回 200/301，且 QQ 已登录
- [ ] AstrBot WebUI 返回 200，日志里能看到 QQ 消息
- [ ] 公网 `https://` 地址可访问
- [ ] **杀掉 AstrBot 进程，90 秒内自动恢复**（验证看门狗真的在工作）
- [ ] 重启手机后，容器与两个服务能自动起来（或被看门狗拉起）

## 与用户交接必须包含

- 公网地址（协议、主机、端口）与各面板的账号/密码/token
- 一键恢复办法（进程重启、容器重装、被卸载包的恢复）
- **明确说明 agent 做不到的事**：扫码登录 QQ（要本人操作）、硬件层面的旁路供电/充电控制
  （多数手机驱动不允许非官方服务写充电控制节点，详见 troubleshooting）

## 通用坑速查

完整版与设备特异项见 `references/troubleshooting.md`。这里只列最容易踩的：

| 现象 | 原因 | 对策 |
|---|---|---|
| `adb shell` 里的命令永不返回 | `su -c` 会等待所有子进程，后台常驻进程让会话一直挂着 | 本地加 `timeout`，或用 `nohup cmd < /dev/null > /dev/null 2>&1 &` 脱离会话 |
| pip 报 `Cannot find path to android app folder` | 容器继承了 Android 的环境变量，platformdirs 误判平台 | `env -i PATH=... HOME=/root python3 -m pip ...` |
| 容器内 `dpkg` 报找不到 `sh`/`rm`/`tar` | `chroot DIR cmd` 继承了宿主 PATH，里面没有这些工具 | 显式设置容器内 PATH |
| `su` 会话里写文件报 `Required key not available` | 某些设备（华为 f2fs + SDP 加密）下 PAM `pam_keyinit` 会新建 keyring，导致拿不到文件密钥 | 注释掉 `pam_keyinit.so`；症状还包括某个进程的 pid 文件变 0 字节 |
| QQ 起不来 / 崩溃 | 缺 X11 库、或在没有 user namespace 的容器里启用了沙箱 | 装 Xvfb 与依赖；务必加 `--no-sandbox` |
| 隧道通了但访问返回 501/403，页面提到"合规" | 中转方拦截明文 HTTP | 本地 TLS 终结后走 https |
| 重启后服务没起来 | OEM 应用启动管理拦了 App 的开机广播 | 用 root 层守护进程自启，别依赖 App |
| 进程莫名其妙消失 | 系统省电策略（Doze / 厂商后台杀手） | 关 Doze、把相关包加入电池白名单、必要时停用厂商的后台管理组件；并用看门狗兜住 |

## 附带的可复用件

- `scripts/probe-adb.sh` —— 阶段 0 的环境探测，一次跑完
- `scripts/svc-watchdog.sh` —— 容器层服务看门狗模板，改服务列表即可用
- `references/root-and-unlock.md` —— 解锁 bootloader 与 root 的做法、风险与验证
- `references/napcat.md`、`astrbot.md`、`tunnel-and-tls.md`、`keepalive.md`、
  `troubleshooting.md` —— 分主题细节
