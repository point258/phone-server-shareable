# 故障速查（按现象找）

## 工具与调用方式类

| 现象 | 原因 | 对策 |
|---|---|---|
| `adb shell` 里的命令**永不返回** | `su -c` 会等所有子进程退出；后台常驻进程（看门狗、daemon）让会话一直挂着 | 本地加 `timeout`；启动常驻进程用 `nohup cmd </dev/null >/dev/null 2>&1 &`；**不要**指望它返回 |
| 命令卡住不动，`sh` 报 `no closing quote` / `unterminated quoted string` | `adb shell "su -c '...'"` 里嵌套转义写坏了，shell 在等输入 | 统一改成：本地写脚本 → `adb push` → `su -c 'sh /path/x.sh'`，**不要用多层引号** |
| `adb push /data/...` 报 `remote secure_mkdirs failed` 或路径变成 Windows 路径 | Git Bash/MSYS 会转换以 `/` 开头的参数 | 设 `MSYS_NO_PATHCONV=1`，或用 `//data/...` |
| `ps -A | grep` 结果不可靠、某进程"消失" | 部分 Android 的 `ps` 只显示进程名不显示完整命令行 | 判断进程一律读 `/proc/PID/cmdline` |
| 脚本判断"进程没在跑"但实际在跑 | PID 复用：残留 pid 文件里的 PID 被新进程占用 | 除了 `kill -0`，再核对 `/proc/PID/cmdline` 是否匹配 |
| 多参数 `pm list packages a b c` 结果像少了 | 该命令一次只接受一个过滤器 | 逐个包查 |

## 容器 / 用户空间类

| 现象 | 原因 | 对策 |
|---|---|---|
| pip 报 `Cannot find path to android app folder` | 容器继承了 `ANDROID_ROOT`/`ANDROID_DATA` 等变量，Python `platformdirs` 误判平台 | `env -i PATH=... HOME=/root LANG=C.UTF-8 python3 -m pip ...` |
| 容器内 `dpkg` 报找不到 `sh`/`rm`/`tar`/`dpkg-deb` | `chroot DIR cmd` 继承了宿主 PATH，里面没有容器工具 | 显式设置容器内 PATH（或在包装脚本里 export PATH） |
| 容器里 `dpkg --configure` 卡在 conffile 交互 | 组件预建了配置文件（如 `/etc/sudoers`），非交互环境下 dpkg 中止 | `dpkg --force-confdef --force-confold --configure <pkg>`，并写 `/etc/apt/apt.conf.d/99dpkg-conf` |
| `su`/SSH 会话里写文件报 `Required key not available`（ENOKEY） | **华为 f2fs + SDP 加密**：文件密钥挂在 session keyring 上，PAM `pam_keyinit.so` 给 `su` 新建 keyring 就丢了密钥 | 注释掉容器内 `/etc/pam.d/{su,su-l,login,runuser,runuser-l,sshd}` 的 `pam_keyinit.so`。**连锁症状**：组件建用户失败、某服务 pid 文件变 0 字节（导致"停止/启动"判断失效） |
| root 执行 `sudo` 报 `root is not in the sudoers file` | 很多精简 rootfs 的 root 不在 sudoers | `echo 'root ALL=(ALL:ALL) NOPASSWD:ALL' >> /etc/sudoers` |
| 卸载容器（`stop -u` 之类）要几十秒无输出 | 逐层 umount 带重试，属正常 | 不要误判为死锁；给足够超时 |
| `mount -t cgroup` 失败 / `Devices cgroup isn't mounted` | 手机内核缺 cgroup/namespace 支持 | 放弃 Docker 路线，改非 Docker 部署（见 SKILL.md 开头） |

## QQ / NapCat 类

| 现象 | 原因 | 对策 |
|---|---|---|
| 安装脚本报"文件夹已存在且不为空(./NapCat)" | 上次失败留下的半成品目录，脚本怕误删 | 删掉/改名后重跑 |
| "验证 NapCat.Shell.zip 失败" | 代理截断了大文件（HTTP 200 但不完整） | 校验大小与 `unzip -l` 能否打开；换一个不截断的代理 |
| QQ 安装包 404 | 脚本里写死的腾讯 CDN 目录已失效 | 自己找当前直链，命名成脚本期望的文件（`QQ.deb`/`QQ.rpm`）放同目录 |
| QQ 启动即崩 | 容器里没有 user namespace，Chromium 沙箱起不来 | 启动必须加 `--no-sandbox`；并确认 Xvfb 与 X11 依赖装齐 |
| 明明在跑却"检测不到端口" | WebUI 可能只监听 IPv6（`host: "::"`） | 同时检查 `/proc/net/tcp` 与 `/proc/net/tcp6` |
| 二维码扫不了 | 二维码约 2 分钟就刷新 | 引导用户在 WebUI 里扫实时的，别提前截图 |
| 怎么判断 QQ 登录成功 | — | `config/` 下出现 `napcat_<QQ号>.json`、`onebot11_<QQ号>.json` |

## 公网 / 隧道类

| 现象 | 原因 | 对策 |
|---|---|---|
| 隧道地址能连 TCP，但 HTTP 返回 501/403，页面提"合规" | 国内中转拦明文 HTTP | 容器内做 TLS 终结（stunnel/nginx 自签证书），隧道指向 TLS 端口，用 `https://` 访问 |
| `stunnel` 启动后调用方卡死 | 配置缺 `foreground = no` 或前台运行 | 后台启动并重定向所有 fd |
| 隧道进程悄悄死掉 | 客户端不保证自动重连 | 看门狗保活；并在日志里记录当前对外地址（远端端口可能被重新分配） |
| 公网能访问但延迟很大 | 用了跨境公益中继 | 换国内节点或自建 frps |

## 保活 / 电源类

| 现象 | 原因 | 对策 |
|---|---|---|
| 重启后服务全没起 | OEM 的"应用启动管理"拦了 App 开机广播 | 用 root 层守护进程（Magisk service.d 等）自启；**别依赖 App** |
| 熄屏一会儿就掉线 | Doze / WiFi 休眠 | 持 wake lock、`wifi_sleep_policy=2`、`dumpsys deviceidle disable` |
| CPU 又变回 `interactive` | 厂商框架会改回 governor | 看门狗每 30 秒重申 |
| 后台进程被系统杀掉 | 厂商后台杀手（如 PowerGenie） | 停用对应包 + 电池白名单；看门狗定期重申（系统更新会改回来） |
| 想限制充电保护电池 | 多数机型驱动不允许第三方写充电控制节点 | 实测：厂商自己的 band 控制节点只接受其 HIDL 服务写入（permissive 也失败），原始 enable 开关会被监控服务秒级改回。**软件层做不到就如实说明**，推荐定时插座按占空比供电 |
| 想关过热保护提性能 | — | **不要做**，这是硬件安全底线；如实告知风险，由用户决定 |

## 交付前自检

- 所有"已完成"的结论都要有实测证据（端口返回码、日志行、截图），不要凭"看起来配好了"下结论
- 主动做一次故障注入（杀掉服务，看是否自愈），这是唯一能证明保活有效的方式
- 把 agent 做不到的事情显式写进交接（扫码登录、硬件级充电控制、断网断电）
