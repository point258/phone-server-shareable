# 前置条件：解锁 bootloader 与 root

## 先给结论

本 skill 要求**一台已解锁 bootloader、且已 root 的 Android 手机**。

如果没有，这是一个**独立的高风险项目**，而且：

- 解锁会**清空手机全部数据**
- 有些机型厂商**已关闭官方解锁渠道**，正规途径根本走不通
- 刷错会**开不了机**（可控的补救手段只有事先备份）
- **agent 不应在用户没有明确知情同意的情况下擅自解锁/刷机**，也不要承诺"一定能 root"

先把这个前提向用户讲清楚，再决定是继续，还是改走"换一台可解锁的旧机 / 直接用 VPS"。

## 为什么必须先解锁 bootloader

`fastboot flash boot` 这类写操作要求 bootloader 处于 unlocked 状态；锁定状态下只能跑官方系统，
拿不到 Magisk/KernelSU 需要的写权限。所以**解锁是 root 的前提，顺序不能反**。

## 解锁（需要用户在物理层面参与）

| 步骤 | 说明 |
|---|---|
| 1. 数据备份 | 解锁会清空全部数据。先迁走照片/聊天记录/账号；有条件先用 TWRP 做一次全量备份 |
| 2. 开开发者选项 | 设置 → 关于手机 → 连点"版本号"；打开 **USB 调试** 和 **OEM 解锁**（部分机型此项要插卡/联网/登录账号并等待若干天才会出现） |
| 3. 进 fastboot | 关机后按机型组合键（多数为 音量下 + 电源） |
| 4. 解锁 | `fastboot flashing unlock`；或走厂商工具（小米 Mi Unlock、部分厂商需申请深度测试、谷歌/索尼等直接 fastboot） |

机型现实差异：

- **华为自 2018 年起不再向用户发放解锁码**，老机型只能通过第三方付费/非官方服务，风险自负。
  遇到华为要如实说明"官方渠道已关闭"，不要试了几天才告诉用户
- 部分运营商定制机、企业定制机永久锁定，直接劝退

解锁后首次开机一般会清数据并要求重新走初始化流程。

## root（三种主流方案）

| 方案 | 适用 | 要点 |
|---|---|---|
| **Magisk** | 最通用，优先推荐 | 用 App 给官方 boot 镜像打补丁，再刷回 |
| KernelSU | 内核支持才行 | 刷带 KSU 的内核，或自行编译 |
| APatch | 较新 | 内核补丁思路，类似 KSU |

### Magisk 最小步骤

1. 拿到**与本机固件版本完全一致**的官方 boot 镜像（从官方固件包解出，或从别处备份）。
   版本不一致会导致无法开机——这一步不能凑合
2. 装 Magisk App → 安装 → 选择并修补一个文件 → 选 boot 镜像 → 得到 `magisk_patched-*.img`
3. ```bash
   adb reboot bootloader
   fastboot flash boot magisk_patched-*.img
   fastboot reboot
   ```
4. 首次启动后打开 Magisk App 完成环境修复（一般需要再重启一次）
5. 验证：`adb shell 'su -c id'` 返回 `uid=0(...) context=u:r:magisk:s0`

**动手前务必把原始 boot 镜像另存一份**。这是刷错后唯一的保命手段，比任何备份工具都直接。

### 现代 Android 的额外坑

- Android 10+ 有 vbmeta/verity 校验，可能需要
  `fastboot --disable-verity --disable-verification flash vbmeta <vbmeta.img>`
- A/B 分区机型要刷到正确 slot：`fastboot getvar current-slot`
- 部分机型刷入后仍需禁用 dm-verity 才能正常启动

## 无屏幕操作时的 root 授权

屏幕不可达（或用户不想点弹窗）时，可以直接往 Magisk 数据库写放行记录：

```bash
# 看现有策略（能看到 policy=2 表示 ALLOW）
adb shell "su -c 'magisk --sqlite \"SELECT * FROM policies\"'"

# 给某应用放行
adb shell "su -c 'magisk --sqlite \"INSERT OR REPLACE INTO policies (uid,policy,until,logging,notification,package_name) VALUES (<uid>,2,0,1,1,''<pkg>'')\"'"
# <uid> 用 dumpsys package <pkg> | grep userId 取
```

前提是 **adb shell 自己已经能拿到 root**（`su -c` 能通）；否则先解决弹窗授权。

## 进入下一阶段前先确认

```bash
adb shell 'su -c id; getprop ro.product.cpu.abi; getprop ro.build.version.release; getprop ro.product.model'
```

三条都符合预期（`uid=0`、架构明确、系统版本已知）再往下走。

另外顺手确认一下这台机器**到底能不能跑 Docker**，好在后面省掉弯路：

```bash
adb shell "su -c 'zcat /proc/config.gz 2>/dev/null | grep -E \"CONFIG_NAMESPACES|CONFIG_CGROUP_DEVICE|CONFIG_MEMCG|CONFIG_VETH\"'"
```

只要看到 `# CONFIG_NAMESPACES is not set` 或 `# CONFIG_CGROUP_DEVICE is not set`，
就**明确告诉用户 Docker 不可用**，并继续走非 Docker 路线（本 skill 本来就假设这条）。

## 一句话交接给用户

> 这一步（解锁 + root）会清空手机数据，且部分机型官方渠道已关闭。请确认你已经解锁并 root，
> 或者明确告诉我你要做这一步、并接受风险与数据清空——否则我无法继续后面的部署。
