# NapCat 安装细节（非 Docker，Linux）

NapCat 是基于 NTQQ 的 OneBot 实现，**它必须有一个 QQ 客户端本体**，自己只是注入进去的框架。
所以在 Linux 上跑 NapCat = 跑一个无头 QQ 客户端 + NapCat。

## 依赖

无头运行 QQ 需要这些东西（Ubuntu/Debian 名）：

```
xvfb screen xauth procps rpm2cpio cpio zip unzip jq curl \
libnss3 libgbm1 libglib2.0-0 libatk1.0-0 libatspi2.0-0 libgtk-3-0 libasound2
```

官方安装脚本会自己 `apt-get install` 这些，但它用 `sudo`——**先确认容器里的 root 能免密 sudo**
（`echo 'root ALL=(ALL:ALL) NOPASSWD:ALL' >> /etc/sudoers`），否则脚本会在装依赖这步失败。

## 一键脚本

官方仓库 `NapNeko/NapCat-Installer`，主脚本 `script/install.sh`（通常会被重命名为 `napcat.sh`）。

```bash
bash napcat.sh --docker n --cli n --proxy 0
```

| 参数 | 含义 |
|---|---|
| `--docker n` | 走 Shell（非 Docker）安装——**手机场景必须用这个** |
| `--cli n` | 不装 TUI-CLI（SSH/无桌面场景其实可以装，看需要） |
| `--proxy 0-n` | 用脚本内置的 GitHub 代理列表，`0` = 不用。国内建议用 `1` 之类 |
| `--force` | 强制重装 LinuxQQ 和 NapCat |

两个会让脚本拒绝执行的状态，处理掉再跑：

- 当前目录存在非空的 `./NapCat` 目录 → 脚本怕误删，要求你先重命名/删除
- 上一次失败可能留下半个 `NapCat` 目录，同样要清掉

## QQ 客户端包（最容易卡住的一步）

脚本里**写死的 QQ 下载链接经常 404**（腾讯会换目录）。脚本支持复用本地包：把包放在脚本同目录、
文件名用脚本期望的 `QQ.deb` / `QQ.rpm`，它就会跳过下载直接用。

拿到当前有效地址的办法：

- 官方下载页 `im.qq.com/linuxqq/download.html` 是 JS 渲染的，直接抓不到直链；它的数据源是
  `https://cdn-go.cn/qq-web/im.qq.com_new/latest/rainbow/linuxConfig.js`，里面有版本号和分架构 URL
- 但注意：那个配置里给的是 `QQNTV2/...` 命名空间，**脚本下载会 403**。可用的公开镜像命名空间是
  `https://qqdl.gtimg.cn/qqfile/QQNT/<NT版本>/beta/<hash>/linuxqq_<版本>_<arch>.deb`
- 也可以参考 AUR 的 `linuxqq` PKGBUILD，维护者会跟着更新可用直链和校验值

架构对应：arm64 → `_arm64.deb`，x86_64 → `_amd64.deb`。下载后验证一下是不是真 deb
（`ar t QQ.deb` 或看文件头 `!<arch>`），**代理镜像截断下载是很常见的坑**——只看 HTTP 200
不够，必须校验大小/格式。

## NapCat 本体包

`https://github.com/NapNeko/NapCatQQ/releases/latest/download/NapCat.Shell.zip`
（几十 MB）。放在脚本同目录命名为 `NapCat.Shell.zip` 时脚本会跳过下载。

国内直连 GitHub 通常只有几百 KB/s，且**不少代理会截断大文件**（拿到 2 MB、8 MB 之类的残缺包）。
下载后务必用 `unzip -l` 校验能正常打开，否则安装会在"验证 NapCat.Shell.zip"这步失败。

### 版本锁定的坑（很容易踩）

脚本把目标 QQ 版本**硬编码**在内部（形如 `linuxqq_target_version="3.2.x-xxxxx"`），安装后还会把
`~/.config/QQ/versions/config.json` 里的版本字段改写成那个固定值。后果：

- 你放了一个**更新**版本的 QQ 包 → 文件是新的、配置被写成旧的 → QQ 起不来，**而且报错完全不指向这里**
- 脚本比较版本时若发现已装更高版本，可能直接跳过安装，你放的包被忽略

最稳的做法是**让脚本用它自己那个版本**（保持它写死的版本号，只把当前可用的同版本包放到同目录）。
确实要用新版本，就把脚本里的版本号与两处下载 URL 一起改掉。

## 安装结果与启动

装完在 `~/Napcat`（脚本输出会打印实际路径）：

```
~/Napcat/opt/QQ/qq                       ← QQ 可执行文件
~/Napcat/opt/QQ/resources/app/app_launcher/napcat/   ← NapCat 本体、config、logs
~/Napcat/opt/QQ/resources/app/app_launcher/napcat/config/webui.json   ← WebUI 端口与 token
```

启动（**`--no-sandbox` 必须加**，容器里没有 user namespace，Chromium 沙箱起不来）：

```bash
# 前台，看日志（首次登录建议这样跑，能直接看到二维码）
xvfb-run -a ~/Napcat/opt/QQ/qq --no-sandbox

# 后台常驻
screen -dmS napcat bash -c "xvfb-run -a ~/Napcat/opt/QQ/qq --no-sandbox"
```

## WebUI 与登录

- 端口默认 **6099**，token 在 `.../napcat/config/webui.json` 里（字段 `host` / `port` / `token`）。
  `host` 可能是 `"::"`（只监听 IPv6）——**验证端口时要同时看 `/proc/net/tcp` 和 `/proc/net/tcp6`**，
  否则会误判成"没监听"。
- 登录：打开 WebUI，页面里会显示**实时刷新的二维码**，用手机 QQ 扫。二维码寿命很短（约 2 分钟），
  所以不要截图发给用户后就指望能用——引导用户自己在 WebUI 里扫。
- 登录成功后 `config/` 下会出现 `napcat_<QQ号>.json`、`onebot11_<QQ号>.json`，
  可用这个判断是否已登录。

## OneBot 接口

在 NapCat WebUI 里配置（WS 服务端 / HTTP 等），记下**端口和 token**，AstrBot 那边要用。
默认端口在不同版本里有差异（3000/3001/随机），**以 WebUI 里显示的为准**。

> **界面步骤本身未逐步验证**：本 skill 只记录到"要在 WebUI 里配置一个 OneBot 服务端并记下
> 端口与 token"这一层。具体菜单名、字段名随 NapCat 版本变化，请以官方文档或 WebUI 实际界面为准，
> 不要照抄别人的截图。
> **但验证方法是可靠的**：AstrBot 日志里出现 QQ 会话消息，就说明这条链路通了。

## 设备无关的注意事项

- QQ 与 NapCat 都比较吃内存（几百 MB 量级），低内存机型要留意
- QQ 客户端在某些内核上会因为缺 `/dev/dri` 而走软件渲染，启动会慢一些，属正常
- 版本更新后 `NapCat.Shell.zip` 与 QQ 版本要匹配，`--force` 重装最省事
