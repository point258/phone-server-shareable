# 公网发布：隧道与 TLS 终结

手机在 NAT 后面（家宽常常还有多层 NAT，甚至运营商级 NAT），**入站端口转发通常不可行**。
可靠做法是让手机**主动向外**建立隧道，绕开所有 NAT。所以这里讲的是 frp 类穿透，不是端口映射。

## 0. 准备：账号与客户端二进制

**注册与取 token**（以 natfrp 为例）：官网注册 → 完成**实名认证**（国内节点基本强制）→ 在
「用户信息」页复制**访问密钥**，它同时是后面 API 的 Bearer token 和 frpc 的登录凭据。
免费账号通常有额度限制（并发隧道数、月流量、限速），建隧道前先确认够用。节点 ID 用
`GET $API/nodes` 取。

**客户端二进制（frpc）**：从服务商下载页按其文档取对应架构的包，架构用
`scripts/probe-adb.sh` 的输出（`arm64` / `amd64`）。选静态链接版本最省事：

```bash
adb push frpc /data/local/tmp/
# 容器内：cp /data/local/tmp/frpc /usr/local/bin/ && chmod 755 /usr/local/bin/frpc
```

两个坑：① 官方直链**带版本号、会变**，写死在脚本里容易 404；② 二进制放容器内即可，
不必和 chroot 外的工具混用。

**把 22 端口发出去之前的检查（重要）**：隧道指向 SSH 前，先确认容器内 SSH 加固已生效：

```bash
sshd -T 2>/dev/null | grep -i '^passwordauthentication'   # 必须是 no
```

没关密码认证就发布 22，等于开放一个可被暴力破解的登录入口。WebUI 这类服务建议走 TLS 端口。

## 选型

| 方案 | 适用 | 说明 |
|---|---|---|
| 自建 frps（一台有公网 IP 的 VPS） | 最推荐 | 延迟最低、完全可控、无额度限制；手机跑 frpc 连自己的服务器 |
| 国内穿透服务（樱花frp/natfrp 等） | 零成本起步 | 有实名与额度限制；节点在国内，延迟尚可 |
| 海外公益中继（bore 等） | 应急 | 免注册、延迟高（跨境往返），不适合长期 |

免费额度通常是**并发隧道数**和**月流量**两个限制。要给「SSH + 多个 WebUI」都开隧道的话，
先确认额度够；不够就把多个 WebUI 收敛到一个端口（nginx 反代）或升级套餐。

## 用穿透服务的 API 建隧道（以 natfrp 为例）

面板能点，但 agent 用 API 更快、可脚本化：

```bash
TOKEN='<访问密钥>'   # 面板「用户信息」里拿
API=https://api.natfrp.com/v4

# 列出隧道（Bearer 认证即用访问密钥）
curl -s -H "Authorization: Bearer $TOKEN" $API/tunnels

# 创建 TCP 隧道（node 是节点 ID，从 $API/nodes 取）
curl -s -X POST $API/tunnels -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  --data-urlencode "name=<名字>" --data-urlencode "type=tcp" \
  --data-urlencode "node=<节点ID>" --data-urlencode "local_ip=127.0.0.1" \
  --data-urlencode "local_port=<容器内端口>"        # remote 留空=随机端口

# 改本地端口（比如改成 TLS 端口）
curl -s -X POST $API/tunnel/edit -H "Authorization: Bearer $TOKEN" \
  -d "id=<隧道ID>" -d "local_ip=127.0.0.1" -d "local_port=<新端口>"

# 删除（注意参数是 ids，逗号分隔，不是 id）
curl -s -X POST $API/tunnel/delete -H "Authorization: Bearer $TOKEN" -d "ids=<id1>,<id2>"
```

客户端（frpc）用访问密钥启动，**把密钥放在配置文件或环境变量里，不要写进命令行**
（会出现在 `ps` 输出里）：

```bash
NATFRP_TOKEN='<访问密钥>' NATFRP_TARGET='<隧道ID1>,<隧道ID2>' /usr/local/bin/frpc -n
```

成功日志会打印对外地址，形如：

```
TCP tunnel started successfully
Connect to your tunnel with >>node.example.com:12345<<
```

## 关键坑：中转会拦明文 HTTP

国内中转受机房合规要求，**常常拦截 TCP 隧道里的明文 HTTP**，返回一个 501/403 页面，
上面写着「您正试图使用 HTTP 协议访问此隧道 … 请启用 HTTPS」。这不是配置错误。

对策是**在容器内做 TLS 终结**，让隧道里跑加密流量，中转看不到内容就不会拦。

### stunnel 方案（最省事，纯 TCP 转发，WebSocket 也不受影响）

```bash
apt-get install -y stunnel4 openssl

# 自签证书，SAN 里带上访问用的域名和节点 IP
cat > /tmp/cert.cnf <<'CNF'
[req]
distinguished_name=dn
x509_extensions=v3
prompt=no
[dn]
CN=<访问域名>
[v3]
subjectAltName=DNS:<访问域名>,DNS:localhost,IP:<节点IP>,IP:127.0.0.1
basicConstraints=CA:FALSE
CNF
openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
  -keyout /etc/stunnel/ld.key -out /etc/stunnel/ld.crt -config /tmp/cert.cnf
cat /etc/stunnel/ld.crt /etc/stunnel/ld.key > /etc/stunnel/ld.pem

cat > /etc/stunnel/stunnel.conf <<'CONF'
foreground = no
pid = /run/stunnel-ld.pid
output = /var/log/stunnel-ld.log
[webui_a]
accept  = 6186            # 隧道指向这个 TLS 端口
connect = 127.0.0.1:6185  # 应用本身的明文端口
cert    = /etc/stunnel/ld.pem
[webui_b]
accept  = 6100
connect = 127.0.0.1:6099
cert    = /etc/stunnel/ld.pem
CONF
stunnel4 /etc/stunnel/stunnel.conf
```

然后把隧道指到 TLS 端口（`tunnel/edit` 改 `local_port`），用户访问
`https://<域名>:<远程端口>`。自签证书浏览器会警告「不受信任」，点继续即可；
数据是加密的，只是签发者不被信任。有域名后换正式证书即可消除。

**坑**：`stunnel4` 不带参数或配置里漏了 `foreground = no` 时会**前台阻塞**，把调用它的
`adb shell` 卡死。后台启动务必 `nohup ... </dev/null >/dev/null 2>&1 &`。

### nginx 方案

需要按路径/域名分流多个 WebUI、或想统一加认证时用 nginx（记得加 WebSocket 升级头：
`proxy_set_header Upgrade $http_upgrade; proxy_set_header Connection "upgrade";`）。
注意 SPA 类面板在**按路径反代**下容易白屏，优先用独立端口。

## 交付给用户前必做

- 用公网地址实测：`curl -sk https://<域名>:<端口>/ -o /dev/null -w '%{http_code}'` → 200
- 记录并转交：公网地址、每个面板的账号/密码/token
- 提醒用户：隧道客户端的远端端口可能被服务方重新分配，**端口变了要去面板/API 查**；
  用看门狗保证 frpc 常驻（见 `keepalive.md`）
