# AstrBot 源码部署细节

## 仓库

**`AstrBotDevs/AstrBot`**（默认分支 `master`）。注意老文档里的 `Soulter/AstrBot` 已经 404——
如果按旧路径拉取会直接 404，别以为是网络问题。

该仓库没有 release 资产，所以走「下载源码压缩包」或 `git clone`：

```bash
# 国内直连慢，可用任意 GitHub 代理前缀；注意有些代理会截断大文件
curl -L -o astrbot.zip https://github.com/AstrBotDevs/AstrBot/archive/refs/heads/master.zip
unzip -q astrbot.zip -d /root/ && mv /root/AstrBot-master /root/AstrBot
# 校验：能列出条目且包含 requirements.txt / main.py
```

## 依赖

- Python **3.10+**
- `python3 -m pip install -r requirements.txt`（依赖很多，**务必用国内 PyPI 镜像**，
  直连 PyPI 可能只有十几 KB/s，几十个包会等到绝望）

```bash
python3 -m pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt
```

需要编译工具的少数包（aiohttp/cryptography 等一般有 arm64 wheel，但保险起见）：

```bash
apt-get install -y python3-pip python3-dev build-essential pkg-config libffi-dev
```

### 容器里装 pip 依赖的必踩坑

Android 环境会带一堆变量（`ANDROID_ROOT`、`ANDROID_DATA`、`ANDROID_ASSETS` …），
Python 的 `platformdirs` 会因此把平台判定为 Android，pip 一启动就崩：

```
OSError: Cannot find path to android app folder
```

对策是用**干净环境**跑 pip（同时显式带上容器自己的 PATH 和 HOME）：

```bash
env -i PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
       HOME=/root LANG=C.UTF-8 TERM=xterm \
       python3 -m pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt
```

运行 AstrBot 本身也建议用同样的干净环境起，避免同类问题。

另外两个小坑：

- `python3 -m venv` 在部分 rootfs 上会失败（`ensurepip` 返回非零）。直接用系统 pip 装到系统
  Python 即可，容器里没必要隔离
- pip 会警告"以 root 运行有风险"，忽略即可

## 启动与验证

```bash
cd /root/AstrBot
nohup env -i PATH=... HOME=/root LANG=C.UTF-8 TZ=Asia/Shanghai python3 main.py \
      > /var/log/astrbot.log 2>&1 </dev/null &
echo $! > /run/astrbot.pid
```

首次启动会在控制台/日志里打印 **WebUI 地址和初始账号密码**，务必抓下来：

```
AstrBot vX.Y.Z WebUI is ready
 ➜  Local: http://localhost:6185
 ➜  Initial username: astrbot
 ➜  Initial password: <随机串>
 ➜  Change it after logging in
```

- WebUI 默认 **6185**（监听 `0.0.0.0`）
- 数据目录 `data/`（配置 `data/cmd_config.json`、日志、插件、知识库）
- 验证：`curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:6185/` → 200
- 交付给用户前提醒他**登录后立刻改密码**

## 接 NapCat（OneBot）

1. 确认 NapCat 侧已经配置好 OneBot 服务端（WS），拿到地址与 token
2. AstrBot WebUI → 平台/适配器 → 添加 `aiocqhttp`（OneBot v11），填 NapCat 的
   `ws://127.0.0.1:<port>` 与 token
3. 验证方式（最可靠）：AstrBot 日志出现真实消息，例如
   ```
   [default] [default(aiocqhttp)] <昵称>/<QQ号>: <消息内容>
   ```
   看到这个就说明 `QQ → NapCat → OneBot → AstrBot` 全链路通了

## 配置模型 provider（本 skill 未逐步验证）

前面几步只保证"链路通"。要让机器人真正会回话，还要在 AstrBot WebUI 里添加**模型 provider**
（供应商、API Key、模型名）。这一步的界面字段随版本变化，**以官方文档为准**，别照抄别人的
截图或字段名。

配置完先在 WebUI 里用自检/对话测试确认能调通，再回 QQ 里试。最常见的"收到消息但不回复"
就是这一步没配或额度用尽——见下面故障表。

## 常见问题

| 现象 | 原因/对策 |
|---|---|
| `Cannot find path to android app folder` | 用 `env -i` 干净环境跑 pip |
| 依赖装到一半报编译错误 | 补 `build-essential python3-dev`，或换 PyPI 镜像重试 |
| WebUI 起不来 / 端口被占 | 看 `data/logs/` 与 `/var/log/astrbot.log`；6185 被占就改 `data/cmd_config.json` 里的 dashboard 端口 |
| 收到消息但不回复 | 检查模型 provider 是否配置、是否有可用额度；适配器通了但模型没配是最常见原因 |
| 进程莫名退出 | 交给看门狗兜住（见 `keepalive.md`），并查日志里的 OOM/Traceback |
