# 保活：让服务在重启、崩溃、省电策略下都活着

目标：不管何时都保持「容器 + NapCat + AstrBot + 隧道」在跑。这需要**两层**看门狗，缺一层都不可靠。

## 为什么不能只靠一层

- **只有容器层**：手机重启后容器不会自己起来，看门狗跟着一起没了
- **只有手机层**：容器起来了但里面的服务崩了，没人管

## 手机层看门狗（root 常驻）

**别依赖 App 自己的开机广播**——各家 OEM 的「应用启动管理 / 自启动管理」默认就把它拦了，
而且不同机型、不同系统版本行为还不一样。跑在 **root 层的守护进程不受应用管理约束**，
这才是可靠的自启途径。落点按 root 方案选：

| root 方案 | 开机脚本位置 |
|---|---|
| Magisk | `/data/adb/service.d/*.sh`（boot 后以 root 执行） |
| KernelSU / APatch | 同上或对应的 module/service 目录 |
| 自定义 init.d | `/system/etc/init.d/` 或发行版对应位置 |

模板要点（完整可复用版本见 `scripts/` 的思路）：

```sh
(
  while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do sleep 5; done
  sleep 40                        # 等系统稳定，别在开机风暴里抢资源
  <持锁 / 应用常驻设置>
  while true; do
    <检查 WiFi 开关与连接>
    <检查容器是否挂载，没挂载就启动容器>
    <检查容器内关键服务是否在跑，没跑就补启动>
    <重申性能与电源策略，厂商可能会改回去>
    sleep 30
  done
) >/dev/null 2>&1 &
```

判断"容器内服务在不在"用 `/proc/PID/cmdline` 扫关键字，**不要用 `ps | grep`**：
很多 Android 的 `ps` 只显示进程名，会给出误导性结果。

## 容器层看门狗

见 `scripts/svc-watchdog.sh`——每 30 秒检查一次进程/端口，掉了就重启，**带冷却时间**避免
"起不来 → 立刻重试 → 起不来"的重启风暴（QQ 这类启动要几十秒的服务尤其需要冷却）。
日志写文件并做行数裁剪，避免长期运行把磁盘写满。

## 熄屏 / 不插电常驻

Android 默认会在熄屏且不插电时进入 Doze，限制后台活动和网络。要让服务照常跑：

```sh
# 内核级阻止休眠（拔插电、熄屏都有效）
echo <自定义名字> > /sys/power/wake_lock      # 释放用 /sys/power/wake_unlock

# 关 Doze 与后台限制
dumpsys deviceidle disable
settings put global app_standby_enabled 0
settings put global adaptive_battery_management_enabled 0
settings put global wifi_sleep_policy 2        # WiFi 永不休眠
dumpsys deviceidle whitelist +<包名>            # 电池优化白名单
```

厂商的后台杀手（如华为 PowerGenie）如果仍在杀进程，可以停用对应包
（`pm disable-user --user 0 <包>`）；**注意这类包有时还兼管权限/通知，停用前想清楚**，
并且它会随系统更新回来，所以看门狗要定期重申。

## 性能

```sh
for d in /sys/devices/system/cpu/cpufreq/policy*; do
  echo performance > $d/scaling_governor     # 需要时立刻满频
done
```

厂商会自行把 governor 改回 `interactive`，**所以看门狗要每 30 秒重申一次**，一次性设置是没用的。
是否把最低频率也锁到最高由用户决定——那意味着常驻满频、明显发热耗电，服务器场景通常不必要。

## 边界（要如实告诉用户）

- **做不到**：手机被强制关机、拔电、路由器/宽带故障
- **做不到**：多数手机的充电控制（旁路供电、限充）。驱动通常只允许厂商自己的服务写充电控制节点，
  原始开关还会被厂商的监控服务秒级改回。想在硬件层解决只能用**定时插座**按占空比供电
- **不建议做**：关闭过热保护（thermal）。那是硬件安全底线，长时间高负载+充电时关闭降频可能损坏电池
- **代价**：持 wake lock + 关 Doze 会显著提高耗电，长期高温满电会加速电池老化——这些都是用户
  知情后自己选择的取舍，agent 的职责是说清楚

## 怎么验证保活真的有效

不要只看"进程在不在"，要**主动制造故障**：

```sh
# 杀掉其中一个服务，等一个看门狗周期以上，再确认它自己回来了
kill -9 <pid>            # 例如 AstrBot 的 python3 main.py
sleep 150
curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:<端口>/    # 期望 200
tail -5 <看门狗日志>      # 期望看到 restart <服务> 的记录
```

注意进程匹配要写准（AstrBot 的 cmdline 是 `python3 main.py`，不含仓库路径；
按错误模式匹配会"杀了 0 个"却看着像成功）。
