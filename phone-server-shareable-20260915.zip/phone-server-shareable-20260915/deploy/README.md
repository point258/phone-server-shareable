> 说明：本文件是**脱敏后的参考实现**文档。原文提到的 `ssh-keys/`、`screenshots/`、`platform-tools/` 等未收录在本包中（前者属隐私，后者可从公开渠道获取）。
> 包内所有真实凭据、地址、账号均已替换为 `<...>` 占位符，使用前请换回你自己的值。

# 手机服务器（<DEVICE_MODEL> / <DEVICE_MODEL>）运维说明

> 用途：把手机做成常驻的 QQ 机器人服务器（NapCat + AstrBot），公网可访问、崩溃自愈、不插电熄屏也运行。

## 当前状态（已全部验证通过）

| 项目 | 值 |
|---|---|
| 宿主 | <DEVICE_MODEL>（<DEVICE_MODEL>），Android 9 / EMUI 9.1，Magisk root |
| 系统 | Ubuntu 22.04.4 LTS (arm64)，Linux Deploy chroot，目录安装于 `/data/local/linux` |
| NapCat | QQ NT + Xvfb 无头运行，WebUI 6099，QQ 已登录（UIN <YOUR_QQ_NUMBER>） |
| AstrBot | v4.28.0 源码部署，WebUI 6185，已通过 aiocqhttp 接上 NapCat，**QQ 消息实测正常收发** |
| 公网入口 | 樱花frp <TUNNEL_NODE_ISP>节点 + 本地 stunnel TLS 终结 |
| 保活 | 两层看门狗 + 电源策略废除 + CPU performance |

### 公网访问地址（必须用 https）

```
AstrBot   https://<TUNNEL_NODE_DOMAIN>:<TUNNEL_REMOTE_PORT_1>/
NapCat    https://<TUNNEL_NODE_DOMAIN>:<TUNNEL_REMOTE_PORT_2>/webui/    Token: <YOUR_NAPCAT_WEBUI_TOKEN>
```

浏览器会提示证书不受信任（自签证书，因为没有域名）→ 点「高级 → 继续前往」。
**用 http:// 访问会被樱花frp 节点拦截**（返回 501，机房内容合规要求），必须 https。

容器 SSH 仍在 22 端口，但**已不对公网开放**；需要命令行时用 `adb shell` 本地进（见下）。

## 架构

```
QQ 客户端 ──► NapCat(QQ NT, Xvfb 无头) ──OneBot(aiocqhttp)──► AstrBot
                                                                │
WebUI(6185/6099) ──► stunnel 本地 TLS 终结(6186/6100) ──► frpc ──► 樱花frp 节点 ──► 公网 https
```

## 保活体系（两层）

### Android 层：`/data/adb/service.d/99-ld-watchdog.sh`
Magisk `service.d` 开机自动执行，**以 root 常驻，不受 EMUI 应用管理约束**。每 30 秒：

1. 重新持有 `ldkeepalive` wake lock（内核级阻止休眠 → 熄屏/不插电也保持运行）
2. WiFi 是否开启；没连上就关开重连
3. 容器是否挂载 → 没挂载执行 `linuxdeploy-cli.sh start -m`；挂载了但 sshd 没跑 → 补一次 start
4. 重申 CPU `performance`（华为会自行改回 interactive）
   每 5 分钟重申：Doze 关闭、PowerGenie 停用、应用待机/自适应电池关闭

开机设置：`wifi_sleep_policy=2`（WiFi 永不休眠）、`stay_on_while_plugged_in=0`（允许熄屏）、
电池优化白名单（Linux Deploy、Magisk）、`dumpsys deviceidle disable`（关 Doze）。

### 容器层：`/usr/local/bin/svc-watchdog`
由 `/etc/rc.local` 启动，每 30 秒检查并按需重启，带冷却防重启风暴：

| 服务 | 检测方式 | 冷却 |
|---|---|---|
| rsyslogd | 进程 | 60s |
| stunnel | 进程 | 60s |
| frpc | 进程 | 60s |
| NapCat | `opt/QQ/qq` 进程 | 180s |
| AstrBot | HTTP 探测 127.0.0.1:6185 | 120s |

日志：`/var/log/svc-watchdog.log`（实测记录过 `restart astrbot`，自愈有效）。

## 电源与性能

- **已废除的华为策略**：PowerGenie 停用、Doze 关闭、应用待机/自适应电池关闭、电池优化白名单
- **CPU**：双簇 `governor=performance`，频率上限解锁到硬件上限（小核 1.84GHz / 大核 2.36GHz）
- **未做**：最低频率没有锁在最高（空闲仍降频，省电）；**过热保护 `soc_thermal` 保持 enabled**（硬件安全底线，关闭有烧电池风险）
- 代价：不插电熄屏常驻会显著耗电，正常几小时到一天，取决于负载

## 已卸载的华为预装（105 个包）

主题、游戏中心/助手、华为视频/阅读/音乐、智慧引擎/助手/语音、推荐服务、钱包、健康、花粉俱乐部、
天气、指南针、录屏、遥控器、驾驶模式、快应用、VR 四件套、应用市场、备份、系统更新、检测修复、
华为商城、预装 VNC、银联支付、手机克隆、讯飞语音 + 整套无用 Google 服务 + 4 个个人应用
（WPS/UC/百度/HiSuite）。另有 GMS、家长控制改为**禁用**。

**保留**：桌面、SystemUI、设置、相机、文件管理、手机管家、输入法、电话/短信/蓝牙/WiFi、
系统框架(systemserver/iaware/pengine/featurelayer)、安全模块、WebView、**Magisk + Linux Deploy**。

**一键回滚**（手机上）：
```bash
su -c 'sh /sdcard/Download/restore-packages.sh'   # 全部恢复
su -c 'pm install-existing com.xxx.yyy'           # 单项恢复
```
清单在 `/sdcard/Download/removed-packages.txt`。

## 日常运维

```bash
# 手机上（需要 root）——以下命令都要用 adb 本地执行
su -c 'sh /data/local/tmp/linuxdeploy-cli.sh status'      # 容器状态
su -c 'sh /data/local/tmp/linuxdeploy-cli.sh start -m'    # 启动容器（会触发 rc.local）
su -c 'sh /data/local/tmp/linuxdeploy-cli.sh shell'       # 进容器
```

容器内服务管理：
```sh
/usr/local/bin/napcat-svc start|stop     # NapCat（Xvfb + QQ）
/usr/local/bin/astrbot-svc start|stop    # AstrBot
/usr/local/bin/frpc-tunnel start|stop|status
/usr/local/bin/svc-watchdog              # 看门狗（常驻，一般不用手动跑）
```

**验证整条链路**：浏览器打开两个 https 地址，能出页面即全链路存活。

## 踩过的坑（重装必看）

1. **华为 f2fs 的 SDP 加密 + PAM `pam_keyinit`**：会让 `su`/SSH 会话里写文件报
   `Required key not available`，表现为建用户失败、**sshd pid 文件变 0 字节**（App 停止/启动失效）。
   解决：注释掉 `/etc/pam.d/{su,su-l,login,runuser,runuser-l,sshd}` 的 `pam_keyinit.so`。
2. **`su -c` 里启动的后台常驻进程会让 `adb shell` 永不返回**（su 等所有子进程）。
   解决：本地加 `timeout`，或用 `nohup ... &` 脱离会话。
3. **chroot 继承 Android 环境变量**（`ANDROID_ROOT`/`ANDROID_DATA`）会让 pip 误判平台为 Android
   并崩溃（`Cannot find path to android app folder`）。解决：`env -i PATH=... HOME=/root python3 -m pip ...`。
4. **chroot 执行命令要显式设 PATH**（继承的 PATH 里没有 sh/rm/tar，dpkg 会报找不到程序）。
5. **`stop -u` 卸载容器很慢**（6 个挂载点各重试 3 次，约 20-40 秒无输出），不是死锁。
6. **Docker 在本机内核上不可能运行**：内核配置缺 `CONFIG_CGROUP_DEVICE`、`CONFIG_MEMCG`、
   `CONFIG_NAMESPACES`（实测 `unshare -p/-n/-u/-i` 全部失败）、`CONFIG_VETH`/`CONFIG_BRIDGE`、
   `CONFIG_BINFMT_MISC`、`CONFIG_KVM`。dockerd 报 `Devices cgroup isn't mounted`。
   **换用户空间（含刷 Linux 发行版）都不解决，因为卡的是内核**；Kirin 960 也没有可用的主线内核。
7. **樱花frp 拦截明文 HTTP**（501，机房内容合规），必须本地 TLS 终结后用 https。
8. **`pm list packages` 一次只接受一个过滤器**，传多个会给出误导性结果；逐个查才准。

## 本目录文件

| 文件 | 用途 |
|---|---|
| `99-ld-watchdog.sh` | Android 层看门狗（Magisk service.d） |
| `svc-watchdog` | 容器层服务看门狗 |
| `frpc-tunnel` / `frpc-tunnel.conf` | 樱花frp 隧道包装脚本与配置（含访问密钥，权限 600） |
| `napcat`/`astrbot` 相关 | 见容器内 `/usr/local/bin/{napcat-svc,astrbot-svc}` |
| `phone-postinstall.sh` | 容器后置配置脚本（重装后恢复 PAM/用户/密钥/rsyslog/穿透） |
| `debloat.sh` / `debloat2.sh` / `d3.sh` | 三步去杂脚本 |
| `ssh-keys/` | SSH 私钥（本地登录用） |
| `screenshots/`、`after-debloat*.png` | 界面截图存档 |
| `platform-tools/` | adb |
