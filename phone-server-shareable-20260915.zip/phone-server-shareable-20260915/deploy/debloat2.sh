#!/system/bin/sh
LOG=/data/local/tmp/debloat2.log
ROLL=/sdcard/Download/removed-packages.txt
: > $LOG
SYS2="
com.vmall.client
com.example.android.notepad
com.hicloud.android.clone
com.iflytek.speechsuite
com.qeexo.smartshot
com.realvnc.android.remote
com.unionpay.tsmservice
com.xy.smartmmsplugin.remote
com.google.android.gms
com.google.android.gsf
com.google.android.backuptransport
com.google.android.configupdater
com.google.android.ext.services
com.google.android.ext.shared
com.google.android.marvin.talkback
com.google.android.onetimeinitializer
com.google.android.overlay.gmsconfig
com.google.android.overlay.settingsProvider
com.google.android.partnersetup
com.google.android.printservice.recommendation
com.google.android.syncadapters.contacts
com.google.android.gms.policy_sidecar_aps
"
echo "=== 第二批卸载 ===" >> $LOG
ok=0; fail=0
for p in $SYS2; do
  r=$(pm uninstall --user 0 "$p" 2>&1 | tr -d '\r')
  case "$r" in
    Success*) echo "  OK   $p" >> $LOG; echo "sys $p" >> $ROLL; ok=$((ok+1));;
    *)        echo "  FAIL $p ($r)" >> $LOG; fail=$((fail+1));;
  esac
done
echo "--- 第二批: 成功 $ok, 失败 $fail ---" >> $LOG
# parentcontrol 无法卸载，改为禁用
pm disable-user --user 0 com.huawei.parentcontrol >> $LOG 2>&1
echo "disabled parentcontrol" >> $LOG
echo "=== DONE2 ===" >> $LOG
