#!/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH
export DEBIAN_FRONTEND=noninteractive
echo "### 安装 stunnel + openssl"
apt-get install -y -qq stunnel4 openssl >/dev/null 2>&1 && echo "  ok"
command -v stunnel4; command -v openssl
echo
echo "### 生成自签证书（含 <TUNNEL_NODE_DOMAIN> 与节点 IP）"
mkdir -p /etc/stunnel
if [ ! -s /etc/stunnel/ld.pem ]; then
cat > /tmp/cert.cnf <<'CNF'
[req]
distinguished_name=dn
x509_extensions=v3
prompt=no
[dn]
CN=<TUNNEL_NODE_DOMAIN>
O=LinuxDeploy Phone
[v3]
subjectAltName=DNS:<TUNNEL_NODE_DOMAIN>,DNS:localhost,IP:<TUNNEL_NODE_IP>,IP:127.0.0.1
basicConstraints=CA:FALSE
CNF
openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
  -keyout /etc/stunnel/ld.key -out /etc/stunnel/ld.crt -config /tmp/cert.cnf >/dev/null 2>&1
cat /etc/stunnel/ld.crt /etc/stunnel/ld.key > /etc/stunnel/ld.pem
chmod 600 /etc/stunnel/ld.pem /etc/stunnel/ld.key
rm -f /tmp/cert.cnf
echo "  已生成"
fi
openssl x509 -in /etc/stunnel/ld.crt -noout -subject -ext subjectAltName 2>&1 | head -4
echo
echo "### stunnel 配置：TLS 终结在 6186/6100"
cat > /etc/stunnel/stunnel.conf <<'CONF'
foreground = no
pid = /run/stunnel-ld.pid
output = /var/log/stunnel-ld.log
[http_astrbot]
accept  = 6186
connect = 127.0.0.1:6185
cert    = /etc/stunnel/ld.pem
[http_napcat]
accept  = 6100
connect = 127.0.0.1:6099
cert    = /etc/stunnel/ld.pem
CONF
pkill -f 'stunnel /etc/stunnel/stunnel.conf' 2>/dev/null
sleep 1
stunnel4 /etc/stunnel/stunnel.conf 2>&1 | head -3
sleep 3
echo "  进程:"; ps -A 2>/dev/null | grep stunnel | head -2
echo
echo "### 本地验证 TLS 终结是否可用"
echo -n "  6186(astrbot): "; curl -sk --max-time 10 -o /dev/null -w "%{http_code}\n" https://127.0.0.1:6186/
echo -n "  6100(napcat):  "; curl -sk --max-time 10 -o /dev/null -w "%{http_code}\n" https://127.0.0.1:6100/webui
