#!/system/bin/sh
# charge-guard：插电时把电池控制在 UPPER~LOWER 区间，避免长期满电导致鼓包/损耗
#   - 达到 UPPER% 停止充电
#   - 降到 LOWER% 恢复充电
#   - 温度 >= HOT 时强制停止充电（安全）
#   - 电量 <= EMERGENCY% 时无条件充电（保底，防止电池被放空）
#   - 拔电时确保充电使能为开（这样下次插上能正常充）
# 由 /data/adb/service.d/99-ld-watchdog.sh 在开机时拉起，并由它保活

UPPER=80        # 达到该电量停止充电
LOWER=70        # 降到该电量恢复充电
HOT=450         # 0.1°C 单位，45.0°C 以上停止充电
EMERGENCY=30    # 低于该电量无条件充电

B=/sys/class/power_supply/Battery
E=/sys/devices/platform/huawei_charger/enable_charger
LOG=/data/local/tmp/charge-guard.log

while true; do
  cap=$(cat $B/capacity 2>/dev/null)
  tmp=$(cat $B/temp 2>/dev/null)
  online=$(cat /sys/class/power_supply/USB/online 2>/dev/null)
  en=$(cat $E 2>/dev/null)

  if [ -z "$cap" ] || [ ! -w "$E" ]; then
    sleep 60; continue
  fi

  # 未插电：确保使能为开，等下次插上能充电
  if [ "$online" != "1" ]; then
    [ "$en" = "1" ] || echo 1 > $E 2>/dev/null
    sleep 60; continue
  fi

  if [ "$cap" -le "$EMERGENCY" ]; then
    [ "$en" = "1" ] || { echo 1 > $E 2>/dev/null; echo "$(date '+%F %T') 低电${cap}% 保底开充" >> $LOG; }
  elif [ "$tmp" -ge "$HOT" ]; then
    [ "$en" = "0" ] || { echo 0 > $E 2>/dev/null; echo "$(date '+%F %T') 温度$((tmp/10))℃ 过高 停充" >> $LOG; }
  elif [ "$cap" -ge "$UPPER" ]; then
    [ "$en" = "0" ] || { echo 0 > $E 2>/dev/null; echo "$(date '+%F %T') 达${cap}% 停充（保护电池）" >> $LOG; }
  elif [ "$cap" -le "$LOWER" ]; then
    [ "$en" = "1" ] || { echo 1 > $E 2>/dev/null; echo "$(date '+%F %T') 降至${cap}% 恢复充电" >> $LOG; }
  fi

  # 日志防膨胀
  if [ -f "$LOG" ] && [ "$(wc -l < $LOG 2>/dev/null)" -gt 500 ]; then
    tail -200 "$LOG" > "$LOG.tmp" 2>/dev/null && mv "$LOG.tmp" "$LOG"
  fi
  sleep 60
done
