#!/system/bin/sh
LOG=/data/local/tmp/debloat3.log; ROLL=/sdcard/Download/removed-packages.txt
: > $LOG
L="com.android.calculator2 com.android.calendar com.android.providers.calendar com.android.deskclock com.android.email com.android.gallery3d com.android.gallery3d.overlay com.android.mediacenter com.android.soundrecorder com.android.printspooler com.android.stk com.android.phone.recorder"
ok=0; fail=0
for p in $L; do
  r=$(pm uninstall --user 0 "$p" 2>&1 | tr -d '\r')
  case "$r" in Success*) echo "OK   $p" >> $LOG; echo "sys $p" >> $ROLL; ok=$((ok+1));; *) echo "FAIL $p ($r)" >> $LOG; fail=$((fail+1));; esac
done
echo "--- 第三批: 成功 $ok, 失败 $fail ---" >> $LOG
