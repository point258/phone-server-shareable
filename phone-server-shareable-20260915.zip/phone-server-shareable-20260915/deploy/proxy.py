"""Minimal threaded HTTP/HTTPS (CONNECT) proxy used to give the USB-connected
Android device internet access through `adb reverse`."""

import socket
import socketserver
import sys
import threading
import time

LISTEN_PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8899
LOG = r"C:\Users\<YOUR_USER>\.zcode\workspace\default\ldtools\proxy.log"

BUFSIZE = 65536


def log(msg):
    line = "%s %s\n" % (time.strftime("%H:%M:%S"), msg)
    with open(LOG, "a", encoding="utf-8") as fh:
        fh.write(line)


def pipe(src, dst):
    try:
        while True:
            data = src.recv(BUFSIZE)
            if not data:
                break
            dst.sendall(data)
    except OSError:
        pass
    finally:
        for s in (src, dst):
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass


def read_headers(rfile):
    head = b""
    while b"\r\n\r\n" not in head:
        chunk = rfile.read(1)
        if not chunk:
            return None
        head += chunk
        if len(head) > 65536:
            return None
    return head


class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        head = read_headers(self.rfile)
        if not head:
            return
        first = head.split(b"\r\n", 1)[0].decode("latin-1")
        parts = first.split()
        if len(parts) < 2:
            return
        method, target = parts[0].upper(), parts[1]

        if method == "CONNECT":
            host, _, port = target.rpartition(":")
            if not host:
                host, port = target, "443"
            try:
                upstream = socket.create_connection((host, int(port)), timeout=20)
            except OSError as exc:
                log("CONNECT FAIL %s -> %s" % (target, exc))
                self.wfile.write(b"HTTP/1.1 502 Bad Gateway\r\n\r\n")
                return
            log("CONNECT %s" % target)
            self.wfile.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
            self.wfile.flush()
            t = threading.Thread(target=pipe, args=(self.connection, upstream), daemon=True)
            t.start()
            pipe(upstream, self.connection)
            try:
                upstream.close()
            except OSError:
                pass
            return

        if not target.lower().startswith("http://"):
            # Only absolute-form requests (proxy style) are understood.
            log("SKIP %s %s" % (method, target[:80]))
            self.wfile.write(b"HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\n\r\n")
            return

        rest = target[7:]
        hostport, _, path = rest.partition("/")
        path = "/" + path
        host, _, port = hostport.partition(":")
        port = int(port) if port else 80
        headers = [ln for ln in head.split(b"\r\n")[1:] if ln]
        body = b""
        for ln in headers:
            if ln.lower().startswith(b"content-length:"):
                body = self.rfile.read(int(ln.split(b":", 1)[1].strip()))
                break
        try:
            upstream = socket.create_connection((host, port), timeout=20)
        except OSError as exc:
            log("GET FAIL %s -> %s" % (target[:120], exc))
            self.wfile.write(b"HTTP/1.1 502 Bad Gateway\r\n\r\n")
            return
        log("GET %s" % target[:160])
        req = ["%s %s HTTP/1.1" % (method, path)]
        for ln in headers:
            low = ln.lower()
            if low.startswith(b"proxy-connection:"):
                continue
            if low.startswith(b"connection:"):
                continue
            req.append(ln.decode("latin-1"))
        req.append("Connection: close")
        upstream.sendall(("\r\n".join(req) + "\r\n\r\n").encode("latin-1") + body)
        pipe(upstream, self.connection)
        try:
            upstream.close()
        except OSError:
            pass


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    srv = Server(("127.0.0.1", LISTEN_PORT), Handler)
    log("proxy listening on 127.0.0.1:%d" % LISTEN_PORT)
    srv.serve_forever()
