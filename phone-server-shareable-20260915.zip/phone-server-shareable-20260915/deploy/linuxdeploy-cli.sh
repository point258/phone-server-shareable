#!/system/bin/sh
ENV_DIR=/data/data/ru.meefik.linuxdeploy/files
export ENV_DIR
export PATH=$ENV_DIR/bin:/system/bin:/system/xbin
cd $ENV_DIR || exit 1
exec sh cli.sh "$@"
