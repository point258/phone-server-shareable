#!/system/bin/sh
LOG=/data/local/tmp/debloat.log
ROLL=/sdcard/Download/removed-packages.txt
: > $LOG

SYS="
com.huawei.android.thememanager
com.huawei.gamebox
com.huawei.gameassistant
com.huawei.android.karaoke
com.huawei.himovie
com.huawei.hwvplayer.youku
com.huawei.hwireader
com.huawei.videoeditor
com.huawei.hiskytone
com.huawei.skytone
com.huawei.lives
com.huawei.fans
com.huawei.health
com.huawei.wallet
com.huawei.appmarket
com.huawei.mycenter
com.huawei.phoneservice
com.huawei.hiai
com.huawei.hiaction
com.huawei.intelligent
com.huawei.vassistant
com.huawei.hicard
com.huawei.suggestion
com.huawei.recsys
com.huawei.contentsensor
com.huawei.trustcircle
com.huawei.scanner
com.huawei.android.totemweather
com.huawei.compass
com.huawei.screenrecorder
com.huawei.android.remotecontroller
com.huawei.vdrive
com.huawei.android.findmyphone
com.huawei.parentcontrol
com.huawei.numberidentity
com.huawei.fastapp
com.huawei.android.instantonline
com.huawei.android.AutoRegSms
com.huawei.android.UEInfoCheck
com.huawei.bd
com.huawei.android.tips
com.huawei.tips
com.huawei.hwstartupguide
com.huawei.android.hwupgradeguide
com.huawei.languagedownloader
com.huawei.KoBackup
com.huawei.hifolder
com.huawei.android.FloatTasks
com.huawei.nearby
com.huawei.smarthome
com.huawei.hilink.framework
com.huawei.android.airsharing
com.huawei.android.instantshare
com.huawei.android.wfdft
com.huawei.iconnect
com.huawei.trustagent
com.huawei.contactscamcard
com.huawei.printservice
com.huawei.android.hwouc
com.huawei.hwdetectrepair
com.huawei.pcassistant
com.huawei.hwonlineprovisionservice
com.huawei.regservice
com.huawei.mmitest
com.huawei.android.projectmenu
com.huawei.vrlauncher
com.huawei.vrphone
com.huawei.vrservice
com.huawei.vrsettings
"

THIRD="cn.wps.moffice_eng com.UCMobile com.baidu.searchbox com.huawei.hisuite"

echo "# 卸载记录 $(date '+%F %T')" > $ROLL
echo "# 恢复命令: pm install-existing <包名>" >> $ROLL

echo "=== 卸载华为预装（--user 0，可恢复）==="
ok=0; fail=0
for p in $SYS; do
  r=$(pm uninstall --user 0 "$p" 2>&1 | tr -d '\r')
  case "$r" in
    Success*) echo "  OK   $p" >> $LOG; echo "sys $p" >> $ROLL; ok=$((ok+1));;
    *)        echo "  FAIL $p ($r)" >> $LOG; fail=$((fail+1));;
  esac
done
echo "--- 预装: 成功 $ok, 失败 $fail ---" >> $LOG

echo "=== 卸载个人应用（含数据）==="
ok2=0; fail2=0
for p in $THIRD; do
  r=$(pm uninstall "$p" 2>&1 | tr -d '\r')
  case "$r" in
    Success*) echo "  OK   $p" >> $LOG; echo "3rd $p" >> $ROLL; ok2=$((ok2+1));;
    *)        echo "  FAIL $p ($r)" >> $LOG; fail2=$((fail2+1));;
  esac
done
echo "--- 个人应用: 成功 $ok2, 失败 $fail2 ---" >> $LOG
echo "=== DONE ===" >> $LOG
