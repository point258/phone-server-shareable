#!/system/bin/sh
# Magisk service.d 开机看门狗：WiFi 在线 + Linux Deploy 容器常驻 + 性能/电源策略重申
# 以 root 常驻后台循环，不依赖 Linux Deploy 应用是否被 EMUI 放行
(
  while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do sleep 5; done
  sleep 40

  # --- 常驻设置 ---
  [ -w /sys/power/wake_lock ] && echo ldkeepalive > /sys/power/wake_lock 2>/dev/null
  settings put global wifi_sleep_policy 2 2>/dev/null         # WiFi 永不休眠
  settings put global stay_on_while_plugged_in 0 2>/dev/null  # 允许熄屏（不用屏幕常亮）
  settings put global app_standby_enabled 0 2>/dev/null
  settings put global adaptive_battery_management_enabled 0 2>/dev/null
  settings put global low_power 0 2>/dev/null
  dumpsys deviceidle disable >/dev/null 2>&1                  # 关 Doze
  dumpsys deviceidle whitelist +ru.meefik.linuxdeploy >/dev/null 2>&1
  dumpsys deviceidle whitelist +com.topjohnwu.magisk >/dev/null 2>&1

  # --- 立即把 CPU 放开到 performance ---
  for d in /sys/devices/system/cpu/cpufreq/policy0 /sys/devices/system/cpu/cpufreq/policy4; do
    hw=$(cat "$d/cpuinfo_max_freq" 2>/dev/null)
    [ -n "$hw" ] && echo "$hw" > "$d/scaling_max_freq" 2>/dev/null
    echo performance > "$d/scaling_governor" 2>/dev/null
  done

  CLI=/data/local/tmp/linuxdeploy-cli.sh
  n=0
  while true; do
    n=$((n+1))

    # 1) wake lock 是否还在（重启后需要重新持有）
    grep -q ldkeepalive /sys/power/wake_lock 2>/dev/null || \
      { [ -w /sys/power/wake_lock ] && echo ldkeepalive > /sys/power/wake_lock 2>/dev/null; }

    # 2) WiFi 开关与连接
    [ "$(settings get global wifi_on 2>/dev/null)" != "1" ] && svc wifi enable 2>/dev/null
    s=$(dumpsys wifi 2>/dev/null | grep -m1 'mWifiInfo SSID' | head -1)
    case "$s" in
      *"<unknown ssid>"*) svc wifi disable 2>/dev/null; sleep 3; svc wifi enable 2>/dev/null;;
    esac

    # 3) 容器是否挂载；没挂载就 start -m
    if ! mount 2>/dev/null | grep -q '/data/local/mnt'; then
      sh "$CLI" start -m >/dev/null 2>&1
    else
      found=0
      for p in /proc/[0-9]*; do
        c=$(tr '\0' ' ' < "$p/cmdline" 2>/dev/null)
        case "$c" in *'sshd -p'*) found=1;; esac
      done
      [ "$found" -eq 0 ] && sh "$CLI" start >/dev/null 2>&1
    fi

    # 4) 每 30 秒重申 CPU 策略（华为会自行改回 interactive）
    for d in /sys/devices/system/cpu/cpufreq/policy0 /sys/devices/system/cpu/cpufreq/policy4; do
      cur=$(cat "$d/scaling_governor" 2>/dev/null)
      [ -n "$cur" ] && [ "$cur" != "performance" ] && echo performance > "$d/scaling_governor" 2>/dev/null
    done

    # 5) 每 10 轮（约 5 分钟）重申 Doze / PowerGenie / 电池设置
    if [ $((n % 10)) -eq 0 ]; then
      dumpsys deviceidle disable >/dev/null 2>&1
      pm list packages -d 2>/dev/null | grep -q 'package:com.huawei.powergenie' || \
        pm disable-user --user 0 com.huawei.powergenie >/dev/null 2>&1
      settings put global app_standby_enabled 0 2>/dev/null
      settings put global adaptive_battery_management_enabled 0 2>/dev/null
    fi

    sleep 30
  done
) >/dev/null 2>&1 &
