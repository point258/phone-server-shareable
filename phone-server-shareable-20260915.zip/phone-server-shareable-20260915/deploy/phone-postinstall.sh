#!/system/bin/sh
# ============================================================================
# Linux Deploy 容器「后置配置」脚本（幂等，可重复执行）
#
# 用途：App 里点过「安装」会重建 /data/local/linux，把这个容器上做过的所有
#       定制一次性恢复（PAM 修复、用户、软件包、SSH 密钥与加固、审计日志）。
#
# 用法（手机上，需要 root）：
#   su -c 'sh /data/local/tmp/phone-postinstall.sh'
# 执行完在 App 里点一下「停止」再「启动」（或重启手机）即可生效。
# ============================================================================

C=/data/local/linux
PUB="<YOUR_SSH_KEY_MATERIAL>"
USER_NAME=android
USER_PASS='<YOUR_CONTAINER_PASSWORD>'

# 容器内 PATH：chroot 会继承 Android 的 PATH（里面没有 sh/rm/tar 等），
# 所以凡是在容器里执行的命令都要显式带上容器自己的 PATH。
CPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
ce() { chroot "$C" /usr/bin/env PATH="$CPATH" "$@"; }

if [ ! -d "$C/etc" ]; then
    echo "!! 找不到容器目录 $C/etc，先在 App 里完成「安装」再来跑这个脚本"
    exit 1
fi

echo "== 1/5 修复 pam_keyinit =="
# 华为 f2fs 的 SDP 加密把文件密钥挂在 session keyring 上，pam_keyinit 会新建
# keyring 导致 su/SSH 会话里写文件报 ENOKEY（Required key not available）。
for f in su su-l login runuser runuser-l sshd; do
    p="$C/etc/pam.d/$f"
    [ -e "$p" ] && sed -i 's/^\(session[[:space:]].*pam_keyinit.*\)$/#\1/' "$p"
done
grep -rn '^[^#]*keyinit' "$C/etc/pam.d/" || echo "   ok: 没有生效中的 pam_keyinit"

echo "== 2/5 用户 $USER_NAME =="
ce /usr/sbin/groupadd -f "$USER_NAME"
if ce /usr/bin/id "$USER_NAME" >/dev/null 2>&1; then
    echo "   用户已存在，跳过创建"
else
    ce /usr/sbin/useradd -m -g "$USER_NAME" -s /bin/bash "$USER_NAME"
fi
echo "$USER_NAME:$USER_PASS" | ce /usr/sbin/chpasswd
UID_N=$(ce /usr/bin/id -u "$USER_NAME")
GID_N=$(ce /usr/bin/id -g "$USER_NAME")
ce /usr/bin/chown -R "$UID_N:$GID_N" "/home/$USER_NAME"
echo "   uid=$UID_N gid=$GID_N"

echo "== 3/5 软件包（sudo / openssh-server / rsyslog）=="
ce DEBIAN_FRONTEND=noninteractive /usr/bin/apt-get install -y sudo openssh-server rsyslog
# Linux Deploy 的 core/sudo 组件会预建 /etc/sudoers，导致 dpkg 卡在 conffile 交互确认。
# 只在 dpkg 状态不干净（iU 等，即已解包但未配置）时才需要修。
if ce /usr/bin/dpkg -l sudo 2>/dev/null | grep -qE '^i[^i ]'; then
    echo "   sudo 处于未配置状态，修复中"
    ce /usr/bin/dpkg --force-confdef --force-confold --configure sudo
else
    echo "   sudo 状态正常，跳过"
fi
printf 'Dpkg::Options { "--force-confdef"; "--force-confold"; };\n' \
    > "$C/etc/apt/apt.conf.d/99dpkg-conf"
# Android chroot 下 apt 需要的兼容选项（不含任何代理）
printf 'Debug::NoDropPrivs "true";\napt::sandbox::seccomp "false";\n' \
    > "$C/etc/apt/apt.conf.d/98android-chroot"

echo "== 4/5 SSH 密钥与加固 =="
mkdir -p "$C/home/$USER_NAME/.ssh" "$C/root/.ssh"
echo "$PUB" > "$C/home/$USER_NAME/.ssh/authorized_keys"
echo "$PUB" > "$C/root/.ssh/authorized_keys"
chmod 700 "$C/home/$USER_NAME/.ssh" "$C/root/.ssh"
chmod 600 "$C/home/$USER_NAME/.ssh/authorized_keys" "$C/root/.ssh/authorized_keys"
ce /usr/bin/chown -R "$UID_N:$GID_N" "/home/$USER_NAME/.ssh"
ce /usr/bin/chown -R 0:0 /root/.ssh
# 写进 sshd_config.d：Ubuntu 的 sshd_config 里 Include 在最前面，所以这里的设置
# 优先级高于主文件 —— App 的「配置」功能会把主文件改回 PasswordAuthentication yes，
# 但改不动这里。
mkdir -p "$C/etc/ssh/sshd_config.d"
cat > "$C/etc/ssh/sshd_config.d/99-hardening.conf" <<'CONF'
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
PermitRootLogin prohibit-password
CONF
chmod 644 "$C/etc/ssh/sshd_config.d/99-hardening.conf"

echo "== 5/6 rc.local（容器启动时拉起全部服务）=="
cat > "$C/etc/rc.local" <<'RC'
#!/bin/sh
# 由 Linux Deploy 的 init 组件执行（INIT_PATH=/etc/rc.local），参数为 start / stop
# 注意：INCLUDE 里必须包含 init/run-parts，否则这个脚本根本不会被调用
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH
STUNNEL_CONF=/etc/stunnel/stunnel.conf
case "$1" in
stop)
    [ -s /run/svc-watchdog.pid ] && kill "$(cat /run/svc-watchdog.pid)" 2>/dev/null
    [ -x /usr/local/bin/napcat-svc ] && /usr/local/bin/napcat-svc stop
    [ -x /usr/local/bin/astrbot-svc ] && /usr/local/bin/astrbot-svc stop
    [ -x /usr/local/bin/frpc-tunnel ] && /usr/local/bin/frpc-tunnel stop
    [ -x /usr/local/bin/bore-tunnel ] && /usr/local/bin/bore-tunnel stop
    [ -s /run/stunnel-ld.pid ] && kill "$(cat /run/stunnel-ld.pid)" 2>/dev/null
    [ -s /run/rsyslogd.pid ] && kill "$(cat /run/rsyslogd.pid)" 2>/dev/null
    ;;
*)
    # 1) 审计日志
    if [ ! -s /run/rsyslogd.pid ] || ! kill -0 "$(cat /run/rsyslogd.pid)" 2>/dev/null; then
        [ -x /usr/sbin/rsyslogd ] && rsyslogd
    fi
    # 2) TLS 终结（中转拦截明文 HTTP 时必需；隧道应指向 TLS 端口而非应用端口）
    if [ -x /usr/bin/stunnel4 ] && [ -s $STUNNEL_CONF ]; then
        { [ -s /run/stunnel-ld.pid ] && kill -0 "$(cat /run/stunnel-ld.pid)" 2>/dev/null; } || \
            stunnel4 $STUNNEL_CONF >/dev/null 2>&1
    fi
    # 3) 隧道客户端
    [ -x /usr/local/bin/frpc-tunnel ] && /usr/local/bin/frpc-tunnel start
    # 4) 业务服务
    [ -x /usr/local/bin/napcat-svc ] && /usr/local/bin/napcat-svc start
    [ -x /usr/local/bin/astrbot-svc ] && /usr/local/bin/astrbot-svc start
    # 5) 看门狗放在最后（它负责长期兜住上面任何一个）
    if [ -x /usr/local/bin/svc-watchdog ]; then
        { [ -s /run/svc-watchdog.pid ] && kill -0 "$(cat /run/svc-watchdog.pid)" 2>/dev/null; } || {
            setsid /usr/local/bin/svc-watchdog >/dev/null 2>&1 &
            echo $! > /run/svc-watchdog.pid
        }
    fi
    ;;
esac
exit 0
RC
chmod 755 "$C/etc/rc.local"

echo "== 6/6 安装服务脚本、隧道程序与配置 =="
# 正在运行的客户端会占住可执行文件（Text file busy），先停掉
for p in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    c=$(cat "/proc/$p/cmdline" 2>/dev/null | tr '\0' ' ')
    case "$c" in *"bore local"*|*"bore-tunnel daemon"*|*"bore-tunnel watch"*|*"frpc "*|*"frpc-tunnel daemon"*|*svc-watchdog*)
        kill -9 "$p" 2>/dev/null ;;
    esac
done
sleep 1
rm -f "$C/run/bore.pid" "$C/run/bore-daemon.pid" "$C/run/bore.endpoint" \
      "$C/run/frpc.pid" "$C/run/frpc-daemon.pid" "$C/run/frpc.endpoint" "$C/run/svc-watchdog.pid"

# 服务脚本：缺一个，rc.local 里对应那步就是空转
for f in svc-watchdog napcat-svc astrbot-svc frpc-tunnel bore-tunnel; do
    if [ -f "/data/local/tmp/$f" ]; then
        cp "/data/local/tmp/$f" "$C/usr/local/bin/$f"
        chmod 755 "$C/usr/local/bin/$f"
        echo "   已安装 /usr/local/bin/$f"
    else
        echo "   !! 缺少 /data/local/tmp/$f —— rc.local 里对应服务起不来"
    fi
done

# 隧道客户端二进制：需按架构自行获取（来源见 skill 的 references/tunnel-and-tls.md）
for f in frpc bore; do
    if [ -f "/data/local/tmp/$f" ]; then
        cp "/data/local/tmp/$f" "$C/usr/local/bin/$f"
        chmod 755 "$C/usr/local/bin/$f"
        echo "   已安装 /usr/local/bin/$f"
    else
        echo "   !! 缺少 /data/local/tmp/$f（隧道客户端二进制，需下载后 push）"
    fi
done

if [ -f /data/local/tmp/frpc-tunnel.conf ]; then
    cp /data/local/tmp/frpc-tunnel.conf "$C/etc/frpc-tunnel.conf"
    chmod 600 "$C/etc/frpc-tunnel.conf"
    chown 0:0 "$C/etc/frpc-tunnel.conf"
    echo "   已安装 /etc/frpc-tunnel.conf（含访问密钥，权限 600）"
else
    echo "   !! 缺少 /data/local/tmp/frpc-tunnel.conf，隧道将无法启动"
fi

# TLS 终结：可选，但中转拦截明文 HTTP 时必需
if [ -f /data/local/tmp/tls.sh ]; then
    cp /data/local/tmp/tls.sh "$C/root/tls.sh"
    chmod 755 "$C/root/tls.sh"
    echo "   已放置 /root/tls.sh（生成自签证书并启动 stunnel）"
    chroot "$C" /bin/sh /root/tls.sh >/dev/null 2>&1 \
        && echo "   已执行 tls.sh（stunnel 就绪）" \
        || echo "   tls.sh 未成功（容器内可能没网或装不上 stunnel4，可手动在容器内跑）"
else
    echo "   （未提供 tls.sh，跳过 TLS 终结——若中转拦明文 HTTP，WebUI 会打不开）"
fi

echo
echo "== 完成 =="
echo "配置文件的 INCLUDE 需要是： bootstrap init/run-parts extra/ssh"
echo "检查： grep '^INCLUDE=' /data/data/ru.meefik.linuxdeploy/files/config/linux.conf"
echo "然后在 App 里「停止」→「启动」，或重启手机。"
